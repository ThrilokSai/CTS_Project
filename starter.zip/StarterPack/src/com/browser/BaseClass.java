package com.browser;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BaseClass {

	public WebDriver driver;
	public Properties prop;
	
	public void launch_browser() throws IOException {
		
		String filename="config_property//configuration.property";
		FileInputStream config_file= new FileInputStream(filename);
		prop = new Properties();
		prop.load(config_file);
		
		String browser_name=prop.getProperty("browser");

		
		if(browser_name.equalsIgnoreCase("chrome")) 
		{
			System.setProperty("webdriver.chrome.driver", "drivers//chromedriver.exe");
			driver= new ChromeDriver();
		}
		
		else if(browser_name.equalsIgnoreCase("firefox")) 
		{
			System.setProperty("webdriver.gecko.driver", "drivers//geckodriver.exe");
			driver= new FirefoxDriver();
		}
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String url=prop.getProperty("url");
		driver.get(url);
		
	
	}
		public void take_screenshot(String path) throws IOException {
		
		
		File source= ((TakesScreenshot)(driver)).getScreenshotAs(OutputType.FILE);	
		FileUtils.copyFile(source, new File(path));
		
		}
}
