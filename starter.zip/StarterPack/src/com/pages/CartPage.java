package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CartPage {

public WebDriver driver;
	
	public  CartPage(WebDriver driver)
	{	
		this.driver=driver;
	}
	
		public void confirmorder() throws InterruptedException {
		Thread.sleep(1800);
		driver.findElement(By.xpath("//input[@class='privacy']")).click();
		driver.findElement(By.xpath("//button[@id='checkoutAccessoriesButton']")).click();
		
	}
	
}
