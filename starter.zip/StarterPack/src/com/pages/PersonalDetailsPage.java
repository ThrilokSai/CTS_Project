package com.pages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.browser.BaseClass;

public class PersonalDetailsPage {

	
public WebDriver driver;
public Properties prop;


	public  PersonalDetailsPage(WebDriver driver)
	{	
		this.driver=driver;
	}

	
	public void personaldetails() throws InterruptedException, IOException {
		
		String filename="config_property//configuration.property";
		FileInputStream config_file= new FileInputStream(filename);
		prop = new Properties();
		prop.load(config_file);
		
		String fname=prop.getProperty("fname");
		String Surname=prop.getProperty("surname");
		String address=prop.getProperty("address");
		String contact=prop.getProperty("contact");
		String email=prop.getProperty("email");
		String confemail=prop.getProperty("confemail");
		
		Select s= new Select(driver.findElement(By.xpath("//*[@id=\"title\"]")));
		s.selectByValue("Ms");
		driver.findElement(By.xpath("//*[@id=\"firstName\"]")).sendKeys(fname);
		driver.findElement(By.xpath("//*[@id=\"lastName\"]")).sendKeys(Surname);
		
		driver.findElement(By.xpath("//*[@id=\"billingAddress\"]")).sendKeys(address);
		Thread.sleep(1855);
		String s1= Keys.chord( Keys.ARROW_DOWN, Keys.ENTER);
	
		driver.findElement(By.xpath("//*[@id=\"billingAddress\"]")).sendKeys(s1);
//		
		driver.findElement(By.xpath("//*[@id=\"contactNumber\"]")).sendKeys(contact);
		driver.findElement(By.xpath("//*[@id=\"emailId\"]")).sendKeys(email);
		driver.findElement(By.xpath("//*[@id=\"checkEmail\"]")).sendKeys(confemail);
		driver.findElement(By.xpath("//*[@id=\"sameDeliveryAccessory\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"checkDeliveryAddressFilled\"]")).click();
	}
	
}
