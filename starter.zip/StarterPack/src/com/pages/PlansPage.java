package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PlansPage {
	
public WebDriver driver;
	
	public  PlansPage(WebDriver driver)
	{	
		this.driver=driver;
	}
	
	public void selectplan() throws InterruptedException {
	driver.findElement(By.linkText("Plans")).click();
	Thread.sleep(11855);
	driver.findElement(By.xpath("//input[@id='starter-pack-plan']")).click();
	driver.findElement(By.xpath("//div[@class='starter-pack-plan-content'] //button[@id='WCC100000000487054']")).click();
	}
}
