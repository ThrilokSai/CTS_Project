package com.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.browser.BaseClass;



public class PaymentsPage  {

public WebDriver driver;
public Properties prop;

	public  PaymentsPage(WebDriver driver)
	{	
		this.driver=driver;
	}
	
	
	public void payments() throws InterruptedException, IOException {
		
		String filename="config_property//configuration.property";
		FileInputStream config_file= new FileInputStream(filename);
		prop = new Properties();
		prop.load(config_file);
		
		String card=prop.getProperty("card");
		String year=prop.getProperty("year");
		String cvv=prop.getProperty("cvv");
	
		driver.switchTo().frame("webPayIframe");
		driver.findElement(By.xpath("//input[@id='card_number']")).sendKeys(card);
		Select date= new Select(driver.findElement(By.xpath("//*[@id=\"year\"]")));
		date.selectByValue(year);
		driver.findElement(By.xpath("//input[@id='ccv_number']")).sendKeys(cvv);
		Thread.sleep(855);
		driver.findElement(By.xpath("//input[@class='btn btn-lg btn-primary btn-default btn-rounded pull-left']")).click();
		Thread.sleep(1855);
		}
	
	
}
