package com.test;

import java.io.IOException;

import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.browser.BaseClass;
import com.pages.CartPage;
import com.pages.PaymentsPage;
import com.pages.PersonalDetailsPage;
import com.pages.PlansPage;

public class TestStarter extends BaseClass {


	@BeforeMethod
	public void launch() throws IOException {
		 launch_browser(); 	 
	}
	
	@Test
	public void starter_pack() throws InterruptedException, IOException {
		PlansPage plan= new PlansPage(driver);
		plan.selectplan();
		
		CartPage cp= new CartPage(driver);
		cp.confirmorder();
		
		PersonalDetailsPage personal= new PersonalDetailsPage(driver);
		personal.personaldetails();
		
		
		
		
		PaymentsPage payment= new PaymentsPage(driver);
		payment.payments();
		
		take_screenshot("Screenshots//screenshot.png");
		
		
	}
	
		
}